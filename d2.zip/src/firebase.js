const firebaseConfig = {
  apiKey: "AIzaSyDJU5uewafSYBTW5hrERBU64T3AL4Vck4Q",
  authDomain: "react-form-68489.firebaseapp.com",
  projectId: "react-form-68489",
  storageBucket: "react-form-68489.appspot.com",
  messagingSenderId: "532560138624",
  appId: "1:532560138624:web:523ca16a2f4e16f2ddf165",
};
