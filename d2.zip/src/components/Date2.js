import Datetime from "react-datetime";
import "react-datetime/css/react-datetime.css";
const Datetimes = () => {
  return <Datetime initialValue={new Date()} />;
};
export default Datetimes;
// return it from your components
