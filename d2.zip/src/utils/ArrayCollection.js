export const CategoryItems = [
  {
    text: "Article Writing",
    condition: false,
  },
  {
    text: "Awards",
    condition: false,
  },
  {
    text: "Business",
    condition: false,
  },
  {
    text: "Dance",
    condition: false,
  },
  {
    text: "Camps",
    condition: false,
  },
  {
    text: "Presentation",
    condition: false,
  },
  {
    text: "Debates",
    condition: false,
  },
  {
    text: "Operations",
    condition: false,
  },
  {
    text: "Literary",
    condition: false,
  },
  {
    text: "Marketing",
    condition: false,
  },
  {
    text: "Conference",
    condition: false,
  },
  {
    text: "Resource",
    condition: false,
  },
  {
    text: "Analytics",
    condition: false,
  },
  {
    text: "Case",
    condition: false,
  },
  {
    text: "Online",
    condition: false,
  },
  {
    text: "Festival",
    condition: false,
  },
  {
    text: "Conclave",
    condition: false,
  },
  {
    text: "Designing",
    condition: false,
  },
  {
    text: "Fashion",
    condition: false,
  },
  {
    text: "Making",
    condition: false,
  },
  {
    text: "Others",
    condition: false,
  },
  {
    text: "Workshops",
    condition: false,
  },
  {
    text: "Fellowships",
    condition: false,
  },
  {
    text: "Discussion",
    condition: false,
  },
  {
    text: "Robotics",
    condition: false,
  },
  {
    text: "Music",
    condition: false,
  },
  {
    text: "Panel",
    condition: false,
  },
  {
    text: "College",
    condition: false,
  },
  {
    text: "Entrepreneurship",
    condition: false,
  },
  {
    text: "Trading",
    condition: false,
  },
  {
    text: "Campus",
    condition: false,
  },
  {
    text: "Dramatics",
    condition: false,
  },
  {
    text: "Data",
    condition: false,
  },
  {
    text: "Data",
    condition: false,
  },
  {
    text: "StScholarshipudy",
    condition: false,
  },
  {
    text: "Campus",
    condition: false,
  },
  {
    text: "Social",
    condition: false,
  },
  {
    text: "Startup",
    condition: false,
  },
  {
    text: "Paper",
    condition: false,
  },
  {
    text: "Finance",
    condition: false,
  },
  {
    text: "Human",
    condition: false,
  },
  {
    text: "Quiz",
    condition: false,
  },
  {
    text: "Science",
    condition: false,
  },
  {
    text: "On",
    condition: false,
  },
  {
    text: "Online",
    condition: false,
  },
  {
    text: "Presentation",
    condition: false,
  },
  {
    text: "Hackathon",
    condition: false,
  },
  {
    text: "Quiz",
    condition: false,
  },
];

export const Domainarrs = [
  { text: "Arts & Science", condition: false },
  {
    text: "Business",
    condition: false,
  },
  { text: "Engineering", condition: false },
  { text: "Others", condition: false },
];
